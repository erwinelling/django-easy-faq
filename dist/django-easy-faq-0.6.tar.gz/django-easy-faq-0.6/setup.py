from setuptools import setup

setup(
    install_requires=[
        'django-ordered-model==3.4.3'
    ],
)